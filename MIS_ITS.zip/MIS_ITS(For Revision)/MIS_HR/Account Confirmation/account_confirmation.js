function requestEdit(userID, EmpID){
    if (!confirm(`Request edit for:\n\nID: ${userID}\nEmployee ID: ${EmpID}\n\nContinue?`)){
        return;
    }

    const field = prompt("Which field do you want to edit?\n\nOptions: firstname, middlename, lastname, contact, department, position", "Type here...");
    if (!field || !['firstname', 'middlename', 'lastname', 'contact', 'department', 'position'].includes(field.toLowerCase())){
        alert("Invalid field selected. Please try again.");
        return;
    }

    const newValue = prompt(`Enter new value for ${field}:`, "");
    if (!newValue){
        alert("No value entered. Request Cancelled.");
        return;
    }

    const reason = prompt("Reason for change: ", "");
    if (!reason){
        alert("No reason provided. Request Cancelled.");
        return;
    }

    const confirmationMessage = 
        `Please confirm your edit request:\n\n` +
        `ID: ${userID}` + `Employee ID: ${EMpID}\n` + `Field to change: ${field}\n` +
        `New Value: ${newValue}\n` + `Reason: ${reason}\n\n` + `Submit this request?`;

    if (confirm(confirmationMessage)){
        alert("Edit request submitted successfully.");
        return;
    }else{
        alert("Edit request cancelled.");
    }
}
