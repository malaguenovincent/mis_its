<?php
session_start();
require_once "src/config.php"; // Ensure this file connects to the database

// If user is not logged in, redirect to login page
if (!isset($_SESSION['id']) || !isset($_SESSION['user_session_id'])) {
    header("location: ../../login.php");
    exit();
}

// Validate the session token
$user_id = $_SESSION["id"];
$session_token = $_SESSION["user_session_id"];

$query = "SELECT user_session_id FROM user_login WHERE id = ?";
$stmt = $link->prepare($query);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$stmt->bind_result($db_user_session_id);
$stmt->fetch();
$stmt->close();

if ($db_user_session_id !== $session_token) {
    // If the session token doesn't match, log the user out
    session_destroy();
    header("location: ../../login.php");
    exit();
}

// Prevent back button access after logout
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
header("Pragma: no-cache"); // HTTP 1.0
header("Expires: 0"); // Proxies
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MIS-HR</title>
    <link rel="stylesheet" href="HR Dashboard/style.css" />

    <script type="text/javascript">
        function preventBack() {
            window.history.forward(); 
        }
        
        setTimeout("preventBack()", 0);
        
        window.onunload = function () { null };
    </script>
    
    <script>
      // Prevent back button navigation
      history.pushState(null, null, location.href);
      window.onpopstate = function () {
        history.pushState(null, null, location.href);
      };
    </script>
  </head>

  <body>
    <div class="container">
      <div class="navigation">
        <ul>
          <li>
            <a href="#">
              <span class="icon"><ion-icon name="laptop-outline"></ion-icon></span>
              <span class="title" style="font-size: 1.5em; font-weight: 500">MIS_HR</span>
            </a>
          </li>
          <li class="hovered">
            <a href="dashboard.php">
              <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
              <span class="title">DASHBOARD</span>
            </a>
          </li>
          <li>
            <a href="employee_registration.php">
              <span class="icon"><ion-icon name="person-add-outline"></ion-icon></span>
              <span class="title">EMPLOYEE REGISTRATION</span>
            </a>
          </li>
          <li>
            <a href="account_confirmation.php">
              <span class="icon"><ion-icon name="document-text-outline"></ion-icon></span>
              <span class="title">ACCOUNT CONFIRMATION</span>
            </a>
          </li>
          <li>
            <a href="view_profile.php">
              <span class="icon"><ion-icon name="person-outline"></ion-icon></span>
              <span class="title">VIEW PROFILE</span>
            </a>
          </li>
          <li>
            <a href="logout.php">
              <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
              <span class="title">LOG OUT</span>
            </a>
          </li>
        </ul>
      </div>

      <!-- main -->
      <div class="main">
        <div class="topbar">
          <div class="toggle">
            <ion-icon name="menu-outline"></ion-icon>
          </div>
          <div class="search">
            <label>
              <input type="text" placeholder="Search here" />
              <ion-icon name="search-outline"></ion-icon>
            </label>
          </div>
          <div class="user">
            <img src="user.jpg" />
          </div>
        </div>
        
        <div class="dash_tables">
            <h2>Employee Registration Requests</h2>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Position</th>
                        <th>Date Submitted</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Query to fetch data from the temporary_login table
                    $query = "SELECT temporary_fname, temporary_mname, temporary_lname, temporary_position, pending_date_request 
                              FROM temporary_login";
                    $result = $link->query($query);

                    if ($result->num_rows > 0) {
                        // Loop through each row and display the data
                        while ($row = $result->fetch_assoc()) {
                            $fullName = $row['temporary_fname'] . ' ' . $row['temporary_mname'] . ' ' . $row['temporary_lname'];
                            $position = $row['temporary_position'];
                            $dateSubmitted = $row['pending_date_request'];
                            echo "<tr>
                                    <td>$fullName</td>
                                    <td>$position</td>
                                    <td>$dateSubmitted</td>
                                    <td>Pending</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='4'>No registration requests found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>


        
   
        <div class="dash_tables">
            <h2>Declined Request</h2>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Reason</th>
                        <th>Date Declined</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Query to fetch data from the declined_request table
                    $query = "SELECT dr.decline_reason, dr.decline_date, 
                                     CONCAT(tl.temporary_fname, ' ', tl.temporary_mname, ' ', tl.temporary_lname) AS full_name
                              FROM declined_request dr
                              JOIN temporary_login tl ON dr.request_id = tl.temporary_id";
                    $result = $link->query($query);

                    if ($result->num_rows > 0) {
                        // Loop through each row and display the data
                        while ($row = $result->fetch_assoc()) {
                            $fullName = $row['full_name'];
                            $reason = $row['decline_reason'];
                            $dateDeclined = $row['decline_date'];
                            echo "<tr>
                                    <td>$fullName</td>
                                    <td>$reason</td>
                                    <td>$dateDeclined</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3'>No declined requests found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        
        <div class="dash_tables">
            <h2>Employee Registration History</h2>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Position</th>
                        <th>Date Approved</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Query to fetch data from user_login and respective position tables
                    $query = "SELECT ul.username, ul.date_reg, ul.position, 
                                     CASE 
                                        WHEN ul.position = 'hr' THEN CONCAT(hr.hr_fname, ' ', hr.hr_mname, ' ', hr.hr_lname)
                                        WHEN ul.position = 'admin' THEN CONCAT(admin.admin_Fname, ' ', admin.admin_Mname, ' ', admin.admin_Lname)
                                        WHEN ul.position = 'tech' THEN CONCAT(tech.tech_fname, ' ', tech.tech_mname, ' ', tech.tech_lname)
                                        WHEN ul.position = 'employee' THEN CONCAT(emp.employee_fname, ' ', emp.employee_mname, ' ', emp.employee_lname)
                                        ELSE 'Unknown'
                                     END AS full_name
                              FROM user_login ul
                              LEFT JOIN hr_info hr ON ul.id = hr.id
                              LEFT JOIN admin_info admin ON ul.id = admin.id
                              LEFT JOIN tech_info tech ON ul.id = tech.id
                              LEFT JOIN employee_info emp ON ul.id = emp.id";
                              
                    $result = $link->query($query);

                    if ($result->num_rows > 0) {
                        // Loop through each row and display the data
                        while ($row = $result->fetch_assoc()) {
                            $fullName = $row['full_name'];
                            $position = ucfirst($row['position']);
                            $dateApproved = $row['date_reg'];
                            echo "<tr>
                                    <td>$fullName</td>
                                    <td>$position</td>
                                    <td>$dateApproved</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3'>No registration history found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
      </div>
    </div>

    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.5.1/dist/chart.min.js"></script>
    <script src="Admin Dashboard/my_chart.js"></script>
    <script>
        let toggle = document.querySelector(".toggle");
        let navigation = document.querySelector(".navigation");
        let main = document.querySelector(".main");

        toggle.onclick = function () {
            navigation.classList.toggle("active");
            main.classList.toggle("active");
        };
        let list = document.querySelectorAll(".navigation li");
        function activeLink() {
            list.forEach((item) => item.classList.remove("hovered"));
            this.classList.add("hovered");
        }
        list.forEach((item) => item.addEventListener("mouseover", activeLink));
    </script>
  </body>
</html>
