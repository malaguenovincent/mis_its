<?php

session_start();
require_once "src/config.php"; // Ensure this file connects to the database

// If user is not logged in, redirect to login page
if (!isset($_SESSION['id']) || !isset($_SESSION['user_session_id'])) {
    header("Location: ../login.php");
    exit();
}

// Validate the session token
$user_id = $_SESSION["id"];
$session_token = $_SESSION["user_session_id"];

$query = "SELECT user_session_id FROM user_login WHERE id = ?";
$stmt = $link->prepare($query);
$stmt->bind_param("s", $user_id);
$stmt->execute();
$stmt->bind_result($db_user_session_id);
$stmt->fetch();
$stmt->close();

if ($db_user_session_id !== $session_token) {
    // If the session token doesn't match, log the user out
    session_destroy();
    header("Location: ../login.php");
    exit();
}

// Query to fetch account information with names and contact from respective position-specific tables
$query = "
    SELECT 
        u.id, 
        u.username, 
        u.email, 
        u.position, 
        u.department, 
        CASE 
            WHEN u.position = 'admin' THEN a.admin_Fname
            WHEN u.position = 'employee' THEN e.employee_fname
            WHEN u.position = 'hr' THEN h.hr_fname
            WHEN u.position = 'tech' THEN t.tech_fname
        END AS fname,
        CASE 
            WHEN u.position = 'admin' THEN a.admin_Mname
            WHEN u.position = 'employee' THEN e.employee_mname
            WHEN u.position = 'hr' THEN h.hr_mname
            WHEN u.position = 'tech' THEN t.tech_mname
        END AS mname,
        CASE 
            WHEN u.position = 'admin' THEN a.admin_Lname
            WHEN u.position = 'employee' THEN e.employee_lname
            WHEN u.position = 'hr' THEN h.hr_lname
            WHEN u.position = 'tech' THEN t.tech_lname
        END AS lname,
        CASE 
            WHEN u.position = 'admin' THEN a.admin_contact
            WHEN u.position = 'employee' THEN e.employee_contact
            WHEN u.position = 'hr' THEN h.hr_contact
            WHEN u.position = 'tech' THEN t.tech_contact
        END AS contact
    FROM user_login u
    LEFT JOIN admin_info a ON u.id = a.id
    LEFT JOIN employee_info e ON u.id = e.id
    LEFT JOIN hr_info h ON u.id = h.id
    LEFT JOIN tech_info t ON u.id = t.id
";

$stmt = $link->prepare($query);
$stmt->execute();
$result = $stmt->get_result();
$accounts = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$filteredAccounts = $accounts;
if (isset($_GET['search'])) {
    $searchTerm = strtolower($_GET['search']);
    $filteredAccounts = array_filter($filteredAccounts, function ($account) use ($searchTerm) {
        return
            strpos(strtolower($account['id']), $searchTerm) !== false ||
            strpos(strtolower($account['fname']), $searchTerm) !== false ||
            strpos(strtolower($account['mname']), $searchTerm) !== false ||
            strpos(strtolower($account['lname']), $searchTerm) !== false ||
            strpos(strtolower($account['contact']), $searchTerm) !== false ||
            strpos(strtolower($account['department']), $searchTerm) !== false ||
            strpos(strtolower($account['position']), $searchTerm) !== false;
    });
}

// Prevent back button access after logout
header("Cache-Control: no-cache, no-store, must-revalidate"); // HTTP 1.1
header("Pragma: no-cache"); // HTTP 1.0
header("Expires: 0"); // Proxies
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MIS-HR - Account Confirmation</title>
    <link rel="stylesheet" href="HR Dashboard/style.css" />
    <link rel="stylesheet" href="Account Confirmation/account_confirmation.css" />
</head>

<body>
    <div class="container">
        <div class="navigation">
            <ul>
                <li>
                    <a href="#">
                        <span class="icon">
                            <ion-icon name="laptop-outline"></ion-icon>
                        </span>
                        <span class="title" style="font-size: 1.5em; font-weight: 500">MIS_HR</span>
                    </a>
                </li>
                <li>
                    <a href="dashboard.php">
                        <span class="icon">
                            <ion-icon name="home-outline"></ion-icon>
                        </span>
                        <span class="title">DASHBOARD</span>
                    </a>
                </li>
                <li>
                    <a href="employee_registration.php">
                        <span class="icon">
                            <ion-icon name="person-add-outline"></ion-icon>
                        </span>
                        <span class="title">EMPLOYEE REGISTRATION</span>
                    </a>
                </li>
                <li class="hovered">
                    <a href="account_confirmation.php">
                        <span class="icon">
                            <ion-icon name="document-text-outline"></ion-icon>
                        </span>
                        <span class="title">ACCOUNT CONFIRMATION</span>
                    </a>
                </li>

                <li>
                    <a href="view_profile.php">
                        <span class="icon">
                            <ion-icon name="person-outline"></ion-icon>
                        </span>
                        <span class="title">VIEW PROFILE</span>
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                        <span class="icon">
                            <ion-icon name="log-out-outline"></ion-icon>
                        </span>
                        <span class="title">LOG OUT</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
                <div class="search">
                    <form method="GET" action="">
                        <label>
                            <input type="text" placeholder="Search here" name="search"
                                value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>" />
                            <ion-icon name="search-outline"></ion-icon>
                        </label>
                    </form>
                </div>
                <div class="user">
                    <img src="../user.jpg" />
                </div>
            </div>

            <div class="account-confirmation-list">
                <div class="cardHeader">
                    <h2>Account Confirmation</h2>
                </div>
                <table>
                    <thead>
                        <tr>

                            <th> ID</th>
                            <th>First Name</th>
                            <th>Middle Name</th>
                            <th>Last Name</th>
                            <th>Contacts</th>
                            <th>Department</th>
                            <th>Position</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($filteredAccounts)) : ?>
                            <tr>
                                <td colspan="8" class="no-results">No accounts found</td>
                            </tr>
                        <?php else : ?>
                            <?php foreach ($filteredAccounts as $account) : ?>
                                <tr>
                                    <td><?= htmlspecialchars($account['id']) ?></td>
                                    <td><?= htmlspecialchars($account['fname']) ?></td>
                                    <td><?= htmlspecialchars($account['mname']) ?></td>
                                    <td><?= htmlspecialchars($account['lname']) ?></td>
                                    <td><?= htmlspecialchars($account['contact']) ?></td>
                                    <td><?= htmlspecialchars($account['department']) ?></td>
                                    <td><?= htmlspecialchars($account['position']) ?></td>
                                    <td>
                                        <button class="request-edit" onclick="requestEdit(<?= $account['id'] ?>, '<?= htmlspecialchars($account['username']) ?>')">
                                            Request Edit
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <script src="Account Confirmation/account_confirmation.js"></script>
    <script>
        let toggle = document.querySelector(".toggle");
        let navigation = document.querySelector(".navigation");
        let main = document.querySelector(".main");

        toggle.onclick = function() {
            navigation.classList.toggle("active");
            main.classList.toggle("active");
        };
        let list = document.querySelectorAll(".navigation li");

        function activeLink() {
            list.forEach((item) => item.classList.remove("hovered"));
            this.classList.add("hovered");
        }
        list.forEach((item) => item.addEventListener("mouseover", activeLink));
    </script>
</body>

</html>