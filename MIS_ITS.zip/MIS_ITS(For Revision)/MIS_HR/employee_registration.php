<?php
// Reset the form submission flag when the user logs out or navigates away
unset($_SESSION['form_submitted']);
require_once "src/config.php"; // Ensure this file connects to the database

// Check if the form has already been submitted
if (isset($_SESSION['form_submitted']) && $_SESSION['form_submitted'] === true) {
    $message = "Form already submitted. Please do not refresh the page.";
} else if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $first_name = trim($_POST['first_name']);
    $middle_name = trim($_POST['middle_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $contact = trim($_POST['contact']);
    $department = trim($_POST['department']);
    $role = trim($_POST['position']);

    // Generate a temporary username and password
    $username = strtolower($first_name . "." . $last_name); // e.g., john.doe
    $temp_password = bin2hex(random_bytes(4)); // Generates an 8-character random password
    $hashed_password = password_hash($temp_password, PASSWORD_DEFAULT); // Hash the temporary password

    // Check if the email or username already exists in the database
    $check_query = "SELECT COUNT(*) FROM temporary_login WHERE temporary_email = ? OR temporary_username = ?";
    $stmt = $link->prepare($check_query);
    $stmt->bind_param("ss", $email, $username);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();

    if ($count > 0) {
        $message = "A user with this email or username already exists.";
    } else if (!empty($first_name) && !empty($last_name) && !empty($email) && !empty($role) && !empty($contact) && !empty($department)) {
        // Get current date and time
        $current_date = date("Y-m-d"); // Format: YYYY-MM-DD
        $current_time = date("H:i:s"); // Format: HH:MM:SS

        // Insert into the temporary_login table
        $insert_query = "INSERT INTO temporary_login (temporary_username, temporary_password, temporary_fname, temporary_mname, temporary_lname, temporary_email, temporary_contact, temporary_department, temporary_position, temporary_session_id, pending_date_request, pending_time_request) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $session_id = session_id(); // Use the current session ID
        $stmt = $link->prepare($insert_query);
        $stmt->bind_param("ssssssssssss", $username, $hashed_password, $first_name, $middle_name, $last_name, $email, $contact, $department, $role, $session_id, $current_date, $current_time);

        if ($stmt->execute()) {
            $message = "Temporary account created successfully. Temporary Username: $username, Temporary Password: $temp_password";
            $_SESSION['form_submitted'] = true; // Mark the form as submitted
        } else {
            $message = "Error creating temporary account.";
        }
        $stmt->close();
    } else {
        $message = "All fields are required.";
    }
}

// Fetch approved users
$approved_users_query = "SELECT id, username, email, position FROM user_login WHERE status = 1 AND position = 'employee'";
$result = $link->query($approved_users_query);

$approved_users = [];
while ($row = $result->fetch_assoc()) {
    $approved_users[] = $row;
}

// Check if there are approved users
//if (empty($approved_users)) {
  //  echo "<p>No approved users available for registration.</p>";
    //exit();
//}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>MIS-HR - Employee Registration</title>
    <link rel="stylesheet" href="HR Dashboard/style.css" />
    <link rel="stylesheet" href="User Registration/user_registration_table.css" />
</head>

<body>
    <div class="container">
        <div class="navigation">
            <ul>
                <li>
                    <a href="#">
                        <span class="icon"><ion-icon name="laptop-outline"></ion-icon></span>
                        <span class="title" style="font-size: 1.5em; font-weight: 500">MIS_HR</span>
                    </a>
                </li>
                <li>
                    <a href="dashboard.php">
                        <span class="icon"><ion-icon name="home-outline"></ion-icon></span>
                        <span class="title">DASHBOARD</span>
                    </a>
                </li>
                <li class="hovered">
                    <a href="employee_registration.php">
                        <span class="icon"><ion-icon name="person-add-outline"></ion-icon></span>
                        <span class="title">EMPLOYEE REGISTRATION</span>
                    </a>
                </li>
                <li>
                    <a href="account_confirmation.php">
                        <span class="icon"><ion-icon name="document-text-outline"></ion-icon></span>
                        <span class="title">ACCOUNT CONFIRMATION</span>
                    </a>
                </li>
                <li>
                    <a href="view_profile.php">
                        <span class="icon"><ion-icon name="person-outline"></ion-icon></span>
                        <span class="title">VIEW PROFILE</span>
                    </a>
                </li>
                <li>
                    <a href="logout.php">
                        <span class="icon"><ion-icon name="log-out-outline"></ion-icon></span>
                        <span class="title">LOG OUT</span>
                    </a>
                </li>
            </ul>
        </div>

        <div class="main">
            <div class="topbar">
                <div class="toggle">
                    <ion-icon name="menu-outline"></ion-icon>
                </div>
                <div class="search">
                    <label>
                        <input type="text" placeholder="Search here" />
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>
                <div class="user">
                    <img src="../user.jpg" />
                </div>
            </div>

            <div class="user-approval-list">
                

                <!-- Add New User Form -->
                <!-- filepath: c:\xampp\htdocs\MIS_ITS\MIS_HR\employee_registration.php -->
<form method="POST" class="add-user-form">
<h2>Employee Registration</h2>
    <div class="form-group">
        <label for="first_name">First Name:</label>
        <input type="text" name="first_name" id="first_name" required />
    </div>
    <div class="form-group">
        <label for="middle_name">Middle Name:</label>
        <input type="text" name="middle_name" id="middle_name" required />
    </div>
    <div class="form-group">
        <label for="last_name">Last Name:</label>
        <input type="text" name="last_name" id="last_name" required />
    </div>
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required />
    </div>
    <div class="form-group">
        <label for="contact">Contact:</label>
        <input type="text" name="contact" id="contact" required />
    </div>
    <div class="form-group">
        <label for="department">Department:</label>
        <input type="text" name="department" id="department" required />
    </div>
    <div class="form-group">
        <label for="position">Position:</label>
        <select name="position" id="position" required>
            <option value="" disabled selected hidden> Select Position</option>
            <option value="employee">Employee</option>
            <option value="admin">Admin</option>
            <option value="tech">Tech</option>
            <option value="hr">Hr</option> 
        </select>
    </div>
    <input type="submit" value="Create User">
</form>



              

                <div class="regitration-history">
                        <h2>Registration History</h2>
                        <table>
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Position</th>
                                    <th>Department</th>
                                    <th>Date Submitted</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php
            // Query to fetch data from user_login and temporary_login
            $query = "SELECT 
                        ul.position AS user_position,
                        ul.department AS user_department,
                        ul.date_reg AS user_date,
                        'Approved' AS status,
                        CASE 
                            WHEN ul.position = 'hr' THEN CONCAT(hr.hr_fname, ' ', hr.hr_mname, ' ', hr.hr_lname)
                            WHEN ul.position = 'admin' THEN CONCAT(admin.admin_Fname, ' ', admin.admin_Mname, ' ', admin.admin_Lname)
                            WHEN ul.position = 'tech' THEN CONCAT(tech.tech_fname, ' ', tech.tech_mname, ' ', tech.tech_lname)
                            WHEN ul.position = 'employee' THEN CONCAT(emp.employee_fname, ' ', emp.employee_mname, ' ', emp.employee_lname)
                            ELSE 'Unknown'
                        END AS full_name
                    FROM user_login ul
                    LEFT JOIN hr_info hr ON ul.id = hr.id
                    LEFT JOIN admin_info admin ON ul.id = admin.id
                    LEFT JOIN tech_info tech ON ul.id = tech.id
                    LEFT JOIN employee_info emp ON ul.id = emp.id
                    UNION ALL
                    SELECT 
                        tl.temporary_position AS user_position,
                        tl.temporary_department AS user_department,
                        tl.pending_date_request AS user_date,
                        'Pending' AS status,
                        CONCAT(tl.temporary_fname, ' ', tl.temporary_mname, ' ', tl.temporary_lname) AS full_name
                    FROM temporary_login tl";

            $result = $link->query($query);

            if ($result->num_rows > 0) {
                // Loop through each row and display the data
                while ($row = $result->fetch_assoc()) {
                    $fullName = $row['full_name'];
                    $position = ucfirst($row['user_position']);
                    $department = $row['user_department'];
                    $dateSubmitted = $row['user_date'];
                    $status = $row['status'];
                    echo "<tr>
                            <td>$fullName</td>
                            <td>$position</td>
                            <td>$department</td>
                            <td>$dateSubmitted</td>
                            <td>$status</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No registration history found.</td></tr>";
            }
            ?>
                            </tbody>
                        </table>
                    </div>
                   
            </div>
            <?php if (isset($message)) { echo "<p>$message</p>"; } ?>
        </div>
    </div>

    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    <script src="User Registration/user_approval.js"></script>
    <script>
        let toggle = document.querySelector(".toggle");
        let navigation = document.querySelector(".navigation");
        let main = document.querySelector(".main");

        toggle.onclick = function () {
            navigation.classList.toggle("active");
            main.classList.toggle("active");
        };
        let list = document.querySelectorAll(".navigation li");
        function activeLink() {
            list.forEach((item) => item.classList.remove("hovered"));
            this.classList.add("hovered");
        }
        list.forEach((item) => item.addEventListener("mouseover", activeLink));
    </script>
</body>
</html>